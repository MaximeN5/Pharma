/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Date;

/**
 *
 * @author Cyrille
 */
public class Report {
    
    int _id;
    int iddrug;
    long nbreport;
    long date;
    String localisation;

    public Report() {
    }

    public int getId() {
        return _id;
    }

    public void setId(int _id) {
        this._id = _id;
    }

    public int getIddrug() {
        return iddrug;
    }

    public void setIddrug(int iddrug) {
        this.iddrug = iddrug;
    }

    public long getNbreport() {
        return nbreport;
    }

    public void setNbreport(long nbreport) {
        this.nbreport = nbreport;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    @Override
    public String toString() {
        return "Report{" + "_id=" + _id + ", iddrug=" + iddrug + ", nbreport=" + nbreport + ", date=" + date + ", localisation=" + localisation + '}';
    }
}
