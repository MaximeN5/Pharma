/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import com.mongodb.DB;
import com.mongodb.MongoClient;

/**
 *
 * @author Cyrille
 */
public class DbCnx {

    MongoClient mongoClient;
    DB db;
    
    public DbCnx() {
        mongoClient = new MongoClient("192.168.137.1", 27017);
        db = mongoClient.getDB("mydb");
    }

    public MongoClient getMongoClient() {
        return mongoClient;
    }

    public void setMongoClient(MongoClient mongoClient) {
        this.mongoClient = mongoClient;
    }

    public DB getDb() {
        return db;
    }

    public void setDb(DB db) {
        this.db = db;
    }
    
}

/*
<!--drugs-->
            <h:dataTable value="#{drugBean.all}" var="drug">
                <h:column><f:facet name="header">id</f:facet>#{drug.idDrug}</h:column>
                <h:column><f:facet name="header">Name</f:facet>#{drug.name}</h:column>
            </h:dataTable>
            <h:dataTable value="#{drugBean.byid}" var="drug">
                <h:column><f:facet name="header">id</f:facet>#{drug.idDrug}</h:column>
                <h:column><f:facet name="header">Name</f:facet>#{drug.name}</h:column>
            </h:dataTable>
            <h:dataTable value="#{drugBean.byName}" var="drug">
                <h:column><f:facet name="header">id</f:facet>#{drug.idDrug}</h:column>
                <h:column><f:facet name="header">Name</f:facet>#{drug.name}</h:column>
            </h:dataTable>
            <h:commandButton value="insert drug" action="#{drugBean.insertDrug()}"></h:commandButton>
            <!--effect-->
            <h:dataTable value="#{effectBean.all}" var="effect">
                <h:column><f:facet name="header">id</f:facet>#{effect.id}</h:column>
                <h:column><f:facet name="header">Name</f:facet>#{effect.name}</h:column>
            </h:dataTable>
            <h:dataTable value="#{effectBean.byid}" var="effect">
                <h:column><f:facet name="header">id</f:facet>#{effect.id}</h:column>
                <h:column><f:facet name="header">Name</f:facet>#{effect.name}</h:column>
            </h:dataTable>
            <h:dataTable value="#{effectBean.byName}" var="effect">
                <h:column><f:facet name="header">id</f:facet>#{effect.id}</h:column>
                <h:column><f:facet name="header">Name</f:facet>#{effect.name}</h:column>
            </h:dataTable>      
            <h:commandButton value="insert effect" action="#{effectBean.insertEffects()}"></h:commandButton>
            <!--drugEffect-->
            <h:dataTable value="#{drugEffectBean.all}" var="drugeffect">
                <h:column><f:facet name="header">id</f:facet>#{drugeffect.id}</h:column>
                <h:column><f:facet name="header">iddrug</f:facet>#{drugeffect.idDrug}</h:column>
                <h:column><f:facet name="header">ideffect</f:facet>#{drugeffect.idEffect}</h:column>
            </h:dataTable>
            <h:dataTable value="#{drugEffectBean.byidDrug}" var="drugeffect">
                <h:column><f:facet name="header">id</f:facet>#{drugeffect.id}</h:column>
                <h:column><f:facet name="header">iddrug</f:facet>#{drugeffect.idDrug}</h:column>
                <h:column><f:facet name="header">ideffect</f:facet>#{drugeffect.idEffect}</h:column>
            </h:dataTable>
            <h:dataTable value="#{drugEffectBean.byidEffect}" var="drugeffect">
                <h:column><f:facet name="header">id</f:facet>#{drugeffect.id}</h:column>
                <h:column><f:facet name="header">iddrug</f:facet>#{drugeffect.idDrug}</h:column>
                <h:column><f:facet name="header">ideffect</f:facet>#{drugeffect.idEffect}</h:column>
            </h:dataTable>      
            <h:commandButton value="insert drugeffect" action="#{drugEffectBean.insertDrug()}"></h:commandButton>  
            <!--Report-->
            <h:dataTable value="#{reportBean.all}" var="report">
                <h:column><f:facet name="header">id</f:facet>#{report.id}</h:column>
                <h:column><f:facet name="header">iddrug</f:facet>#{report.iddrug}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{report.date}</h:column>
                <h:column><f:facet name="header">nbReport</f:facet>#{report.nbreport}</h:column>
                <h:column><f:facet name="header">local</f:facet>#{report.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{reportBean.byDate}" var="report">
                <h:column><f:facet name="header">id</f:facet>#{report.id}</h:column>
                <h:column><f:facet name="header">iddrug</f:facet>#{report.iddrug}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{report.date}</h:column>
                <h:column><f:facet name="header">nbReport</f:facet>#{report.nbreport}</h:column>
                <h:column><f:facet name="header">local</f:facet>#{report.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{reportBean.byidDrug}" var="report">
                <h:column><f:facet name="header">id</f:facet>#{report.id}</h:column>
                <h:column><f:facet name="header">iddrug</f:facet>#{report.iddrug}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{report.date}</h:column>
                <h:column><f:facet name="header">nbReport</f:facet>#{report.nbreport}</h:column>
                <h:column><f:facet name="header">local</f:facet>#{report.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{reportBean.byReportgt}" var="report">
                <h:column><f:facet name="header">id</f:facet>#{report.id}</h:column>
                <h:column><f:facet name="header">iddrug</f:facet>#{report.iddrug}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{report.date}</h:column>
                <h:column><f:facet name="header">nbReport</f:facet>#{report.nbreport}</h:column>
                <h:column><f:facet name="header">local</f:facet>#{report.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{reportBean.byReportlt}" var="report">
                <h:column><f:facet name="header">id</f:facet>#{report.id}</h:column>
                <h:column><f:facet name="header">iddrug</f:facet>#{report.iddrug}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{report.date}</h:column>
                <h:column><f:facet name="header">nbReport</f:facet>#{report.nbreport}</h:column>
                <h:column><f:facet name="header">local</f:facet>#{report.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{reportBean.byReportbetwn}" var="report">
                <h:column><f:facet name="header">id</f:facet>#{report.id}</h:column>
                <h:column><f:facet name="header">iddrug</f:facet>#{report.iddrug}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{report.date}</h:column>
                <h:column><f:facet name="header">nbReport</f:facet>#{report.nbreport}</h:column>
                <h:column><f:facet name="header">local</f:facet>#{report.localisation}</h:column>
            </h:dataTable>
            <h:commandButton value="insert report" action="#{reportBean.insert()}"></h:commandButton> 
            <!--Tweet-->
            <h:dataTable value="#{tweetBean.all}" var="tweet">
                <h:column><f:facet name="header">id</f:facet>#{tweet.id}</h:column>
                <h:column><f:facet name="header">idDrug</f:facet>#{tweet.idDrug}</h:column>
                <h:column><f:facet name="header">message</f:facet>#{tweet.msg}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{tweet.date.date}</h:column>
                <h:column><f:facet name="header">pays</f:facet>#{tweet.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{tweetBean.byDategt}" var="tweet">
                <h:column><f:facet name="header">id</f:facet>#{tweet.id}</h:column>
                <h:column><f:facet name="header">idDrug</f:facet>#{tweet.idDrug}</h:column>
                <h:column><f:facet name="header">message</f:facet>#{tweet.msg}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{tweet.date.date}</h:column>
                <h:column><f:facet name="header">pays</f:facet>#{tweet.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{tweetBean.byDatelt}" var="tweet">
                <h:column><f:facet name="header">id</f:facet>#{tweet.id}</h:column>
                <h:column><f:facet name="header">idDrug</f:facet>#{tweet.idDrug}</h:column>
                <h:column><f:facet name="header">message</f:facet>#{tweet.msg}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{tweet.date.date}</h:column>
                <h:column><f:facet name="header">pays</f:facet>#{tweet.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{tweetBean.byLocal}" var="tweet">
                <h:column><f:facet name="header">id</f:facet>#{tweet.id}</h:column>
                <h:column><f:facet name="header">idDrug</f:facet>#{tweet.idDrug}</h:column>
                <h:column><f:facet name="header">message</f:facet>#{tweet.msg}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{tweet.date.date}</h:column>
                <h:column><f:facet name="header">pays</f:facet>#{tweet.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{tweetBean.byid}" var="tweet">
                <h:column><f:facet name="header">id</f:facet>#{tweet.id}</h:column>
                <h:column><f:facet name="header">idDrug</f:facet>#{tweet.idDrug}</h:column>
                <h:column><f:facet name="header">message</f:facet>#{tweet.msg}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{tweet.date.date}</h:column>
                <h:column><f:facet name="header">pays</f:facet>#{tweet.localisation}</h:column>
            </h:dataTable>
            <h:dataTable value="#{tweetBean.byidDrug}" var="tweet">
                <h:column><f:facet name="header">id</f:facet>#{tweet.id}</h:column>
                <h:column><f:facet name="header">idDrug</f:facet>#{tweet.idDrug}</h:column>
                <h:column><f:facet name="header">message</f:facet>#{tweet.msg}</h:column>
                <h:column><f:facet name="header">date</f:facet>#{tweet.date.date}</h:column>
                <h:column><f:facet name="header">pays</f:facet>#{tweet.localisation}</h:column>
            </h:dataTable>
            <h:commandButton value="insert tweet" action="#{tweetBean.insert()}"></h:commandButton> 
*/

/*
<h:form>
                <h:commandButton value="insert drugeffect" action="#{drugBean.insertDrug()}"></h:commandButton> 
                <h:commandButton value="FDA DRUG" action="#{fdaBean.drugList}"></h:commandButton>
                <h:commandButton value="insert drugeffect" action="#{drugEffectBean.insertDrugEffect()}"></h:commandButton>  
                <h:commandButton value="insert report" action="#{reportBean.insert()}"></h:commandButton>  
            </h:form>
*/
