/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import com.google.gson.annotations.SerializedName;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Cyrille
 */
public class Tweet {
    
    int _id;
    int idDrug;
    String message;
    String localisation;
    GsonDate date;


    public Tweet() {
    }

    public int getId() {
        return _id;
    }

    public void setId(int _id) {
        this._id = _id;
    }

    public String getMsg() {
        return message;
    }

    public void setMsg(String msg) {
        this.message = msg;
    }

    public GsonDate getDate() {
        return date;
    }

    public void setDate(GsonDate date) {
        this.date = date;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String Localisation) {
        this.localisation = Localisation;
    }

    public int getIdDrug() {
        return idDrug;
    }

    public void setIdDrug(int idDrug) {
        this.idDrug = idDrug;
    }
    
    @Override
    public String toString() {
        return "Tweet{" + "_id=" + _id + ", msg=" + message + ", date=" + date + ", Localisation=" + localisation + '}';
    }
    
    public static class GsonDate {

        @SerializedName("$date")
        public Date date;

        public GsonDate(String date) throws ParseException {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'");
            this.date = format.parse(date);
        }

        public Date getDate() {
            return date;
        }

        public void setDate(Date date) {
            this.date = date;
        }
    }
    
}
