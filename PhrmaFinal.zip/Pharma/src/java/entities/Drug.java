/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author Cyrille
 */
public class Drug {
    
    int _id;
    String name;

    public Drug(String name) {
        this._id = 1;
        this.name = name;
    }

    public Drug() {
    }

    public int getIdDrug() {
        return _id;
    }

    public void setIdDrug(int idDrug) {
        this._id = idDrug;
    }

    public String getName() {
        return name;
    }

    public void setName(String Name) {
        this.name = Name;
    }

    @Override
    public String toString() {
    return "Drug{" + "_id=" + _id + ", Name=" + name + '}';
    }
   
}
