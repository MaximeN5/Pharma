/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author Cyrille
 */
public class DrugEffect {
    
    int _id;
    int iddrug;
    int ideffect;
    long nbreaction;

    public DrugEffect() {
    }

    public int getId() {
        return _id;
    }

    public void setId(int id) {
        this._id = id;
    }

    public int getIdDrug() {
        return iddrug;
    }

    public void setIdDrug(int idDrug) {
        this.iddrug = idDrug;
    }

    public int getIdEffect() {
        return ideffect;
    }

    public void setIdEffect(int idEffect) {
        this.ideffect = idEffect;
    }

    public long getNbreaction() {
        return nbreaction;
    }

    public void setNbreaction(long nbreaction) {
        this.nbreaction = nbreaction;
    }

    @Override
    public String toString() {
        return "DrugEffect{" + "_id=" + _id + ", iddrug=" + iddrug + ", ideffect=" + ideffect + ", nbreaction=" + nbreaction + '}';
    }
}
