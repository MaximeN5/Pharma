/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import entities.DbCnx;
import entities.Signal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Cyrille
 */
public class SignalCont {

     DbCnx cnx;

    public SignalCont() {

        cnx = new DbCnx();

        if (!cnx.getDb().collectionExists("signal")) {
            //I can confirm that the collection is created at this point.
            DBObject options = BasicDBObjectBuilder.start().add("autoIndexID", true).get();
            cnx.getDb().createCollection("signal",options);
            //I would highly recommend you check the 'school' DBCollection to confirm it was actually created
            System.out.println("Collection signal created successfully");
        }
    }
    public void insert (int idDrug)
    {
        int type=0;
        FdaRequest fda = new FdaRequest();
        DrugCnx d = new DrugCnx();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        Calendar c = Calendar.getInstance();
        Date max = c.getTime();
        c.add(Calendar.YEAR, -1);
        Date min = c.getTime();

        long nextId = cnx.getDb().getCollection("signal").count();
        nextId+=1;
        System.out.println(nextId);
        BasicDBObject doc = new BasicDBObject();
        doc.put("_id", nextId);
        doc.put("iddrug",idDrug);

        //System.out.println("Insert SIGNAL" +dateFormat.format(min)+"    " +dateFormat.format(max));
        long l = fda.nbReportsBetwn(d.findById(idDrug).getName(), dateFormat.format(min), dateFormat.format(max));
        System.out.println("SIGNAL "+idDrug+"   "+l);
        if (l < 3000) {
            type = 1;
        } else if (l > 6000) {
            type = 3;
        } else {
            type = 2;
        }
        doc.put("type", type);
        cnx.getDb().getCollection("signal").insert(doc);
        System.out.println("insert Done");
    }

    public List<Signal> findAll(){
        Gson gson = new Gson();
        DBCursor iterable = cnx.getDb().getCollection("signal").find();
        String resultat = "[";
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";

        }
        resultat+="]";
        System.out.println(resultat);
        List<Signal> signaux = gson.fromJson(resultat, new TypeToken<List<Signal>>(){}.getType());

        for(Signal s : signaux)
        {
            System.out.println(s.toString());
        }
        return signaux;
    }

    public List<Signal> findByIdDrug(int idDrug)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("iddrug", idDrug);
        DBCursor iterable = cnx.getDb().getCollection("signal").find(document);
        String resultat = "[";
        System.out.println("selectbyidDrug");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Signal> signaux = gson.fromJson(resultat, new TypeToken<List<Signal>>(){}.getType());

        return signaux;
    }

    public List<Signal> findBytype(int type)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("type", type);
        DBCursor iterable = cnx.getDb().getCollection("signal").find(document);
        String resultat = "[";
        System.out.println("selectBytype");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Signal> signaux = gson.fromJson(resultat, new TypeToken<List<Signal>>(){}.getType());

        for(Signal r : signaux)
        {
            System.out.println(r.toString());
        }

        return signaux;
    }
}
