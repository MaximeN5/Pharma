/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Controller.FdaRequest.DrugMiddle;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author Cyrille
 */
public class FdaRequest {

    public FdaRequest() {
    }
   
    public List<DrugMiddle> drugList (){
        
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = new Date();
        String Date_today = dateFormat.format(date);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -730);
        Date todate1 = cal.getTime();
        String Date_2yearAgo = dateFormat.format(todate1);
        List<DrugMiddle> list = null;

        try {

            URL conn = new URL("https://api.fda.gov/drug/event.json?api_key=eUWrZmAEorE9pwc8oymkEXNj3IX4hC3szeGXrXRo&"
                    + "search=receivedate:[" + Date_2yearAgo + "+TO+" + Date_today + "]+"
                    + "AND+serious:1&count=patient.drug.openfda.brand_name.exact");
            URLConnection yc = conn.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            String result="";
            String output = "";

            while ((output = in.readLine()) != null) {
                result = result.concat(output);
            }
            //System.out.println(result);
            JSONParser parser = new JSONParser();
            Object resultObject = parser.parse(result);
            System.out.println(result);

            JSONObject myJSONResult = (JSONObject) resultObject;
            JSONArray resu = (JSONArray) myJSONResult.get("results");
            System.out.println(resu);

            Gson gson = new Gson();
            list = gson.fromJson(resu.toString(), new TypeToken<List<DrugMiddle>>() {}.getType());
            
            for (DrugMiddle e : list) {
                System.out.println(e.toString());
                System.out.println("-------");
            }

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }

        return list;
    }
    
    public List<DrugMiddle> drugEffectList (String drug){
      
        List<DrugMiddle> list = null;
        try {

            URL conn = new URL("https://api.fda.gov/drug/event.json?api_key=eUWrZmAEorE9pwc8oymkEXNj3IX4hC3szeGXrXRo&"
                    + "search=patient.drug.openfda.brand_name:"+drug
                    + "&count=patient.reaction.reactionmeddrapt.exact");
            URLConnection yc = conn.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            String result="";
            String output = "";

            while ((output = in.readLine()) != null) {
                result = result.concat(output);
            }
            //System.out.println(result);
            JSONParser parser = new JSONParser();
            Object resultObject = parser.parse(result);
            System.out.println(result);

            JSONObject myJSONResult = (JSONObject) resultObject;
            JSONArray resu = (JSONArray) myJSONResult.get("results");
            System.out.println(resu);

            Gson gson = new Gson();
            list = gson.fromJson(resu.toString(), new TypeToken<List<DrugMiddle>>() {}.getType());
            
            for (DrugMiddle e : list) {
                System.out.println(e.toString());
                System.out.println("-------");
                if (e.getCount()<1000)
                    list.remove(list.indexOf(e));
            }

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }

        return list;
    }
    
    public long nbReports (String drug){
      
        List<DrugMiddle> list = null;
        JSONObject resu1 = null;
        try {

            URL conn = new URL("https://api.fda.gov/drug/event.json?api_key=eUWrZmAEorE9pwc8oymkEXNj3IX4hC3szeGXrXRo&"
                    + "search=patient.drug.openfda.brand_name:"+drug);
            URLConnection yc = conn.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            String result="";
            String output = "";

            while ((output = in.readLine()) != null) {
                result = result.concat(output);
            }
            //System.out.println(result);
            JSONParser parser = new JSONParser();
            Object resultObject = parser.parse(result);
            System.out.println(result);

            JSONObject myJSONResult = (JSONObject) resultObject;
            JSONObject resu = (JSONObject) myJSONResult.get("meta");
            resu1 = (JSONObject) resu.get("results");

            System.out.println(resu1.get("total"));

            

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }

        return (long) resu1.get("total");
    }
    
    public List<DrugMiddle> reportCountry (String drug){
      
        List<DrugMiddle> list = null;
        try {

            URL conn = new URL("http://api.fda.gov/drug/event.json?api_key=eUWrZmAEorE9pwc8oymkEXNj3IX4hC3szeGXrXRo&"
                    + "search=patient.drug.openfda.brand_name:"+drug
                    + "&count=primarysource.reportercountry.exact&limit=10");
            URLConnection yc = conn.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            String result="";
            String output = "";

            while ((output = in.readLine()) != null) {
                result = result.concat(output);
            }
            //System.out.println(result);
            JSONParser parser = new JSONParser();
            Object resultObject = parser.parse(result);
            System.out.println(result);

            JSONObject myJSONResult = (JSONObject) resultObject;
            JSONArray resu = (JSONArray) myJSONResult.get("results");
            System.out.println(resu);

            Gson gson = new Gson();
            list = gson.fromJson(resu.toString(), new TypeToken<List<DrugMiddle>>() {
            }.getType());
            for (int i=0;i<list.size();i++) {
                System.out.println(list.get(i).toString());
                System.out.println("-------");
                if(list.get(i).getTerm().length()==2 || list.get(i).getTerm().compareTo("COUNTRY NOT SPECIFIED")==0){
                    list.remove(list.get(i));
                }
            }

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }

        return list;
    }
    public long nbReportsBetwn (String drug, String min, String max){
      
        List<DrugMiddle> list = null;
        JSONObject resu1 = null;
        try {

            URL conn = new URL("http://api.fda.gov/drug/event.json?api_key=eUWrZmAEorE9pwc8oymkEXNj3IX4hC3szeGXrXRo&"
                    + "search=receivedate:["+min+"+TO+"+max+"]+AND+"+
                    "patient.drug.medicinalproduct:"+drug);
            System.out.println(conn);
            URLConnection yc = conn.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            String result="";
            String output = "";

            while ((output = in.readLine()) != null) {
                result = result.concat(output);
            }
            System.out.println(result);
            JSONParser parser = new JSONParser();
            Object resultObject = parser.parse(result);
            System.out.println(result);

            JSONObject myJSONResult = (JSONObject) resultObject;
            JSONObject resu = (JSONObject) myJSONResult.get("meta");
            resu1 = (JSONObject) resu.get("results");

            System.out.println(resu1.get("total"));

            

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }

        return (long) resu1.get("total");
    }
    
    public List<DrugMiddle> nbReportsPerYear (String drug){
      
        List<DrugMiddle> list = null;
        JSONObject resu1 = null;
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        Calendar c = Calendar.getInstance();
        Date max = c.getTime();
        Date min;
        DrugMiddle dg = new DrugMiddle();
        ArrayList<DrugMiddle> retour = new ArrayList<DrugMiddle>();
        for (int i = 10; i > 0; i--) {
            c.add(Calendar.YEAR,-1);
            min = c.getTime();

            try {

                URL conn = new URL("http://api.fda.gov/drug/event.json?api_key=eUWrZmAEorE9pwc8oymkEXNj3IX4hC3szeGXrXRo&"
                        + "search=receivedate:["+dateFormat.format(min)+"+TO+"+dateFormat.format(max)+"]+AND+"
                        + "patient.drug.medicinalproduct:" + drug);
                URLConnection yc = conn.openConnection();
                
                BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                String result = "";
                String output = "";

                while ((output = in.readLine()) != null) {
                    result = result.concat(output);
                }
                //System.out.println(result);
                JSONParser parser = new JSONParser();
                Object resultObject = parser.parse(result);
                //System.out.println(result);

                JSONObject myJSONResult = (JSONObject) resultObject;
                JSONObject resu = (JSONObject) myJSONResult.get("meta");
                resu1 = (JSONObject) resu.get("results");

                System.out.println(resu1.get("total")+"Date min "+dateFormat.format(min)+"Date max "+dateFormat.format(max) );
                dg.count=(long) resu1.get("total");
                dg.term="Date min "+dateFormat.format(min)+"Date max "+dateFormat.format(max) ;
                System.out.println(dg.toString());
                retour.add(new DrugMiddle((long) resu1.get("total"), min+"-----"+max));
                

            } catch (Exception e) {
                System.err.println(e.getClass().getName() + ": " + e.getMessage());
            }
            max = min;

        }
        return retour;
    }
    
    public static class DrugMiddle{
        
        long count;
        String term;

        public DrugMiddle() {
        }

        public DrugMiddle(long count, String term) {
            this.count = count;
            this.term = term;
        }
        

        public long getCount() {
            return count;
        }

        public void setCount(long count) {
            this.count = count;
        }

        public String getTerm() {
            return term;
        }

        public void setTerm(String term) {
            this.term = term;
        }

        @Override
        public String toString() {
            return "DrugMiddle{" + "count=" + count + ", term=" + term + '}';
        }
    }
}

//recuperer par rapport a un intervalle de temps
//la map les pays les plus touchés
//l'evolution de nb de reports dans le temps par medicament
//les dates par rapport a ask a patient
//complètude vigibase et fda
//signal = SOMME(FDA, ASK, TWITTER)
//analyse de blog paramétré pour twitter ou doctissimo (le nombre de fois qu"on a mal parlé d'un médicament)
//analyse sémantique