/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import entities.DbCnx;
import entities.Tweet;
import entities.Tweet.GsonDate;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Cyrille
 */
public class TweetCont {
    
    DbCnx cnx;

    public TweetCont() {
        
        cnx = new DbCnx();
        
        if (!cnx.getDb().collectionExists("tweet")) {
            //I can confirm that the collection is created at this point.
            DBObject options = BasicDBObjectBuilder.start().add("autoIndexID", true).get();
            cnx.getDb().createCollection("tweet",options);
            //I would highly recommend you check the 'school' DBCollection to confirm it was actually created
            System.out.println("Collection tweet created successfully");
        }
    }
    
    public void insert (String message,int idDrug, GsonDate date, String local)
    {
        DrugCnx d = new DrugCnx();
        long nextId = cnx.getDb().getCollection("tweet").count();
        nextId+=1;
        System.out.println(nextId);
        BasicDBObject doc = new BasicDBObject();
        doc.put("_id", nextId);
        doc.put("idDrug", idDrug);
        doc.put("message",message);
        doc.put("localisation",local);
        doc.put("date", date.getDate());
        cnx.getDb().getCollection("tweet").insert(doc);
        System.out.println("insert Done");
    }
    
    public List<Tweet> findAll(){
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'").create();
        DBCursor iterable = cnx.getDb().getCollection("tweet").find();
        String resultat = "[";
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";

        }
        resultat+="]";
        System.out.println(resultat);
        List<Tweet> tweets = gson.fromJson(resultat, new TypeToken<List<Tweet>>(){}.getType());
        
        for(Tweet t : tweets)
        {
            System.out.println(t.toString());
        }
        return tweets;
    }
    public Tweet findById(int id)
    {
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'").create();
        BasicDBObject document = new BasicDBObject();
        document.put("_id", id);
        DBCursor iterable = cnx.getDb().getCollection("tweet").find(document);
        String resultat = "";
        System.out.println("selectbyidTweet");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
        }
        resultat+="";
        System.out.println(resultat);
        Tweet tweet = gson.fromJson(resultat, Tweet.class);
        
        return tweet;
    }
    
    public List<Tweet> findByIdDrug(int idDrug)
    {
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'").create();
        BasicDBObject document = new BasicDBObject();
        document.put("idDrug", idDrug);
        DBCursor iterable = cnx.getDb().getCollection("tweet").find(document);
        String resultat = "[";
        System.out.println("selectbyidDrug");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Tweet> tweets = gson.fromJson(resultat, new TypeToken<List<Tweet>>(){}.getType());
        
        for(Tweet t : tweets)
        {
            System.out.println(t.toString());
        }
        
        return tweets;
    }
    
    public List<Tweet> findByDategt(Date date)
    {
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'").create();
        BasicDBObject document = new BasicDBObject();
        document.put("date", new BasicDBObject("$gte", date));
        DBCursor iterable = cnx.getDb().getCollection("tweet").find(document);
        String resultat = "[";
        System.out.println("selectbydategt");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Tweet> tweets = gson.fromJson(resultat, new TypeToken<List<Tweet>>(){}.getType());
        
        for(Tweet t : tweets)
        {
            System.out.println(t.toString());
        }
        
        return tweets;
    }
    
    public List<Tweet> findByDatelt(Date date)
    {
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'").create();
        BasicDBObject document = new BasicDBObject();
        document.put("date", new BasicDBObject("$lte", date));
        DBCursor iterable = cnx.getDb().getCollection("tweet").find(document);
        String resultat = "[";
        System.out.println("selectbydatelt");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Tweet> tweets = gson.fromJson(resultat, new TypeToken<List<Tweet>>(){}.getType());
        
        for(Tweet t : tweets)
        {
            System.out.println(t.toString());
        }
        
        return tweets;
    }
    
    public List<Tweet> findByLocal(String local)
    {
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'").create();
        BasicDBObject document = new BasicDBObject();
        document.put("localisation", local);
        DBCursor iterable = cnx.getDb().getCollection("tweet").find(document);
        String resultat = "[";
        System.out.println("selectbyLocal");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Tweet> tweets = gson.fromJson(resultat, new TypeToken<List<Tweet>>(){}.getType());
        
        for(Tweet t : tweets)
        {
            System.out.println(t.toString());
        }
        
        return tweets;
    }
    

}
