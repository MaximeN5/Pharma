/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import entities.DbCnx;
import entities.Drug;
import entities.DrugEffect;
import entities.Effect;
import java.util.List;

/**
 *
 * @author Cyrille
 */
public class DrugEffectCont {
    
    DbCnx cnx;
    DrugCnx d = new DrugCnx();
    EffectCont e = new EffectCont();

    public DrugEffectCont() {
        
        cnx = new DbCnx();
        
        if (!cnx.getDb().collectionExists("drugeffect")) {
            //I can confirm that the collection is created at this point.
            DBObject options = BasicDBObjectBuilder.start().add("autoIndexID", true).get();
            cnx.getDb().createCollection("drugeffect",options);
            //I would highly recommend you check the 'school' DBCollection to confirm it was actually created
            System.out.println("Collection drugeffect created successfully");
        }
    }
    public void insert (String drugName, String effectName, long nbreaction)
    {
        
        long nextId = cnx.getDb().getCollection("drugeffect").count();
        nextId+=1;
        System.out.println(nextId);
        BasicDBObject doc = new BasicDBObject();
        if (e.findByNameFirst(effectName)==null)
            e.insert(effectName);
        doc.put("_id", nextId);
        doc.put("iddrug",d.findByNameFirst(drugName).getIdDrug());
        doc.put("ideffect", e.findByNameFirst(effectName).getId());
        doc.put("nbreaction", nbreaction);
        cnx.getDb().getCollection("drugeffect").insert(doc);
        System.out.println("insert Done");
    }
    
    public List<DrugEffect> findAll(){
        Gson gson = new Gson();
        DBCursor iterable = cnx.getDb().getCollection("drugeffect").find();
        String resultat = "[";
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";

        }
        resultat+="]";
        System.out.println(resultat);
        List<DrugEffect> drugeffects = gson.fromJson(resultat, new TypeToken<List<DrugEffect>>(){}.getType());
        
        for(DrugEffect d : drugeffects)
        {
            System.out.println(d.toString());
        }
        return drugeffects;
    }
    
    public List<DrugEffect> findByIdDrug(int idDrug)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("iddrug", idDrug);
        DBCursor iterable = cnx.getDb().getCollection("drugeffect").find(document);
        String resultat = "[";
        System.out.println("selectbyidDrug");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<DrugEffect> effectsId = gson.fromJson(resultat, new TypeToken<List<DrugEffect>>(){}.getType());
        
        return effectsId;
    }
    
    public List<DrugEffect> findByIdEffect(int idEffect)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("ideffect", idEffect);
        DBCursor iterable = cnx.getDb().getCollection("drugeffect").find(document);
        String resultat = "[";
        System.out.println("selectbyidEffect");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<DrugEffect> drugsid = gson.fromJson(resultat, new TypeToken<List<DrugEffect>>(){}.getType());
        
        for(DrugEffect d : drugsid)
        {
            System.out.println(d.toString());
        }
        
        return drugsid;
    }
    
    
}
