/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DB;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import entities.DbCnx;
import entities.Drug;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Cyrille
 */
public class DrugCnx {

    DbCnx cnx;
    public DrugCnx() {
        cnx = new DbCnx();
        if (!cnx.getDb().collectionExists("drug")) {
            //I can confirm that the collection is created at this point.
            DBObject options = BasicDBObjectBuilder.start().add("autoIndexID", true).get();
            cnx.getDb().createCollection("drug",options);
            //I would highly recommend you check the 'school' DBCollection to confirm it was actually created
            System.out.println("Collection drug created successfully");
        }
    }
    
    public void insert (Drug d)
    {
        
        long nextId = cnx.getDb().getCollection("drug").count();
        nextId+=1;
        System.out.println(nextId);
        BasicDBObject doc = new BasicDBObject();
        doc.put("_id", String.valueOf(nextId));
        doc.put("name", d.getName());
        cnx.getDb().getCollection("drug").insert(doc);
        System.out.println("insert Done");
    }
    
    public List<Drug> findAll(){
        Gson gson = new Gson();
        DBCursor iterable = cnx.getDb().getCollection("drug").find();
        String resultat = "[";
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";

        }
        resultat+="]";
        System.out.println(resultat);
        List<Drug> drugs = gson.fromJson(resultat, new TypeToken<List<Drug>>(){}.getType());
        
        for(Drug d : drugs)
        {
            System.out.println(d.toString());
        }
        return drugs;
    }
    
    public Drug findById(int id)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("_id", String.valueOf(id));
        DBCursor iterable = cnx.getDb().getCollection("drug").find(document);
        String resultat = "";
        System.out.println("selectbyid");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
        }
        System.out.println(resultat);
        Drug drug = gson.fromJson(resultat, Drug.class);
        
        return drug;
    }
    
    public List<Drug> findByName(String name)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("name", name);
        DBCursor iterable = cnx.getDb().getCollection("drug").find(document);
        String resultat = "[";
        System.out.println("selectbyname");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Drug> drugs = gson.fromJson(resultat, new TypeToken<List<Drug>>(){}.getType());
        
        for(Drug d : drugs)
        {
            System.out.println(d.toString());
        }
        
        long nextId = cnx.getDb().getCollection("drug").find().size();
        nextId+=1;
        System.out.println(nextId);
        return drugs;
    }
    
    public Drug findByNameFirst(String name)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("name", name);
        DBCursor iterable = cnx.getDb().getCollection("drug").find(document);
        String resultat = "";
        System.out.println("selectbyname");
        Boolean bool = true;
        while(iterable.hasNext() && bool)
        {
            resultat+=iterable.next();
            bool = false;
        }
        System.out.println(resultat);
        Drug drugs = gson.fromJson(resultat, Drug.class);
        
        return drugs;
    }
    //select from collection
        //BasicDBObject document = new BasicDBObject();
        //document.put("_id", "4");
        //document.put("name", "aspirin");
        //document.put("_id", new BasicDBObject("$gt", "1"));
        //DBCursor iterable = db.getCollection("drug").find(document);
    //http://howtodoinjava.com/nosql/mongodb/mongodb-selectqueryfind-documents-examples/#select_all
    
    //https://jira.mongodb.org/browse/SERVER-3880
}
/*

<!--
            
            -->
*/
