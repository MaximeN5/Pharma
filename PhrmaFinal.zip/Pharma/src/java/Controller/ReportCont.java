/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import entities.DbCnx;
import entities.Report;
import java.util.List;

/**
 *
 * @author Cyrille
 */
public class ReportCont {
    
    DbCnx cnx;

    public ReportCont() {
        
        cnx = new DbCnx();
        
        if (!cnx.getDb().collectionExists("report")) {
            //I can confirm that the collection is created at this point.
            DBObject options = BasicDBObjectBuilder.start().add("autoIndexID", true).get();
            cnx.getDb().createCollection("report",options);
            //I would highly recommend you check the 'school' DBCollection to confirm it was actually created
            System.out.println("Collection report created successfully");
        }
    }
    public void insert (String drugName, long date, long nbReport, String local)
    {
        DrugCnx d = new DrugCnx();
        long nextId = cnx.getDb().getCollection("report").count();
        nextId+=1;
        System.out.println(nextId);
        BasicDBObject doc = new BasicDBObject();
        doc.put("_id", nextId);
        doc.put("iddrug",d.findByNameFirst(drugName).getIdDrug());
        doc.put("date", date);
        doc.put("nbreport", nbReport);
        doc.put("localisation", local);
        cnx.getDb().getCollection("report").insert(doc);
        System.out.println("insert Done");
    }
    
    public List<Report> findAll(){
        Gson gson = new Gson();
        DBCursor iterable = cnx.getDb().getCollection("report").find();
        String resultat = "[";
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";

        }
        resultat+="]";
        System.out.println(resultat);
        List<Report> reports = gson.fromJson(resultat, new TypeToken<List<Report>>(){}.getType());
        
        for(Report r : reports)
        {
            System.out.println(r.toString());
        }
        return reports;
    }
    
    public List<Report> findByIdDrug(int idDrug)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("iddrug", idDrug);
        DBCursor iterable = cnx.getDb().getCollection("report").find(document);
        String resultat = "[";
        System.out.println("selectbyidDrug");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Report> reports = gson.fromJson(resultat, new TypeToken<List<Report>>(){}.getType());
        
        return reports;
    }
    
    public List<Report> findByDate(long date)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("date", date);
        DBCursor iterable = cnx.getDb().getCollection("report").find(document);
        String resultat = "[";
        System.out.println("selectbydate");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Report> reports = gson.fromJson(resultat, new TypeToken<List<Report>>(){}.getType());
        
        for(Report r : reports)
        {
            System.out.println(r.toString());
        }
        
        return reports;
    }
    
    public List<Report> findByNbreportgt(int nbreport)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("nbreport", new BasicDBObject("$gte", nbreport));
        DBCursor iterable = cnx.getDb().getCollection("report").find(document);
        String resultat = "[";
        System.out.println("selectbydate");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Report> reports = gson.fromJson(resultat, new TypeToken<List<Report>>(){}.getType());
        
        for(Report r : reports)
        {
            System.out.println(r.toString());
        }
        
        return reports;
    }
    
    public List<Report> findByNbreportlt(int nbreport)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("nbreport", new BasicDBObject("$lte", nbreport));
        DBCursor iterable = cnx.getDb().getCollection("report").find(document);
        String resultat = "[";
        System.out.println("selectbydate");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Report> reports = gson.fromJson(resultat, new TypeToken<List<Report>>(){}.getType());
        
        for(Report r : reports)
        {
            System.out.println(r.toString());
        }
        
        return reports;
    }
    
    public List<Report> findByNbreportbetwn(int min,int max)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("nbreport", new BasicDBObject("$gte",min ).append("$lte", max));
        DBCursor iterable = cnx.getDb().getCollection("report").find(document);
        String resultat = "[";
        System.out.println("selectbydate");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Report> reports = gson.fromJson(resultat, new TypeToken<List<Report>>(){}.getType());
        
        for(Report r : reports)
        {
            System.out.println(r.toString());
        }
        
        return reports;
    }
}
