/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import entities.DbCnx;
import entities.Drug;
import entities.Effect;
import java.util.List;

/**
 *
 * @author Cyrille
 */
public class EffectCont {
    
    DbCnx cnx;

    public EffectCont() {
        cnx = new DbCnx();
        if (!cnx.getDb().collectionExists("effect")) {
            //I can confirm that the collection is created at this point.
            DBObject options = BasicDBObjectBuilder.start().add("autoIndexID", true).get();
            cnx.getDb().createCollection("effect",options);
            //I would highly recommend you check the 'school' DBCollection to confirm it was actually created
            System.out.println("Collection effect created successfully");
        }
    }
    
    public void insert (String name)
    {
        
        BasicDBObject doc = new BasicDBObject();
        doc.put("name", name);

        System.out.println(cnx.getDb().getCollection("effect").find(doc).count());
        if(cnx.getDb().getCollection("effect").find(doc).count()==0){
            long nextId = cnx.getDb().getCollection("effect").count();
            nextId += 1;
            System.out.println(nextId);
            doc.put("_id", nextId);
            cnx.getDb().getCollection("effect").insert(doc);
            System.out.println("insert Done");
        }
        
    }
    
    public List<Effect> findAll(){
        Gson gson = new Gson();
        DBCursor iterable = cnx.getDb().getCollection("effect").find();
        String resultat = "[";
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";

        }
        resultat+="]";
        System.out.println(resultat);
        List<Effect> effects = gson.fromJson(resultat, new TypeToken<List<Effect>>(){}.getType());
        
        for(Effect e : effects)
        {
            System.out.println(e.toString());
        }
        return effects;
    }
    
    public Effect findById(int id)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("_id", id);
        DBCursor iterable = cnx.getDb().getCollection("effect").find(document);
        String resultat = "";
        System.out.println("selectbyid");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
        }
        System.out.println(resultat);
        Effect effect = gson.fromJson(resultat, Effect.class);
        
        return effect;
    }
    
    public List<Effect> findByName(String name)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("name", name);
        DBCursor iterable = cnx.getDb().getCollection("effect").find(document);
        String resultat = "[";
        System.out.println("selectbyname");
        while(iterable.hasNext())
        {
            resultat+=iterable.next();
            if(iterable.hasNext())
                resultat+=",";
        }
        resultat+="]";
        System.out.println(resultat);
        List<Effect> effects = gson.fromJson(resultat, new TypeToken<List<Effect>>(){}.getType());
        
        for(Effect e : effects)
        {
            System.out.println(e.toString());
        }
        
        long nextId = cnx.getDb().getCollection("drug").find().size();
        nextId+=1;
        System.out.println(nextId);
        return effects;
    }
    
    public Effect findByNameFirst(String name)
    {
        Gson gson = new Gson();
        BasicDBObject document = new BasicDBObject();
        document.put("name", name);
        DBCursor iterable = cnx.getDb().getCollection("effect").find(document);
        String resultat = "";
        System.out.println("selectbyname");
        Boolean bool = true;
        while(iterable.hasNext() && bool)
        {
            resultat+=iterable.next();
            bool=false;
        }
        System.out.println(resultat);
        Effect effects = gson.fromJson(resultat, Effect.class);
        
        return effects;
    }

}
/*

  
            <h:dataTable value="#{effectBean.all}" var="effect">
                <h:column><f:facet name="header">id</f:facet>#{effect.id}</h:column>
                <h:column><f:facet name="header">Name</f:facet>#{effect.name}</h:column>
            </h:dataTable>
            <h:dataTable value="#{effectBean.byid}" var="effect">
                <h:column><f:facet name="header">id</f:facet>#{effect.id}</h:column>
                <h:column><f:facet name="header">Name</f:facet>#{effect.name}</h:column>
            </h:dataTable>
            <h:dataTable value="#{effectBean.byName}" var="effect">
                <h:column><f:facet name="header">id</f:facet>#{effect.id}</h:column>
                <h:column><f:facet name="header">Name</f:facet>#{effect.name}</h:column>
            </h:dataTable>
*/