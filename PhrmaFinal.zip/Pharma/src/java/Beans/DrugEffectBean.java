/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Controller.DrugCnx;
import Controller.DrugEffectCont;
import Controller.FdaRequest;
import Controller.FdaRequest.DrugMiddle;
import entities.Drug;
import entities.DrugEffect;
import java.util.Arrays;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author Cyrille
 */
@ManagedBean
@RequestScoped
public class DrugEffectBean {

    /**
     * Creates a new instance of DrugEffectBean
     */
    DrugEffectCont de = new DrugEffectCont();
    public DrugEffectBean() {
    }
    
    public List<DrugEffect> getAll()
    {
        return de.findAll();

    }
 
    public List<DrugEffect> getByidDrug(int i)
    {
        return de.findByIdDrug(i);
    }
    
    public List<DrugEffect> getByidEffect(int i)
    {
        return de.findByIdEffect(i);

    }
    public void insertDrugEffect()
    {
        FdaRequest fda = new FdaRequest();
        DrugCnx drug = new DrugCnx();
        //List<Drug> list = drug.findAll();
        List<DrugMiddle> mid ;
        /*
        for (Drug d : list){
            mid= null;
            mid = fda.drugEffectList(d.getName());
            for (DrugMiddle dm : mid) {
                de.insert(d.getName(), dm.getTerm(), dm.getCount());
            }
            System.out.println("insertDrug done");

        }*/
        List<String> st = Arrays.asList("AVANDIA","ENBREL","LASIX") ;
      
        for (String d : st){
            mid= null;
            mid = fda.drugEffectList(d);
            for (DrugMiddle dm : mid) {
                de.insert(d, dm.getTerm(), dm.getCount());
            }
            System.out.println("insertDrugEffect done");

        }
    }
    
    
}
