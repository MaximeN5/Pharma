/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Controller.DrugCnx;
import Controller.FdaRequest;
import Controller.FdaRequest.DrugMiddle;
import Controller.ReportCont;
import entities.Report;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author Cyrille
 */
@ManagedBean
@RequestScoped
public class ReportBean {

    /**
     * Creates a new instance of ReportBean
     */
    ReportCont rc = new ReportCont();
    DrugCnx dc = new DrugCnx();
    static String DrugName="";
    
    public ReportBean() {
    }
    
    public List<Report> getAll()
    {
        return rc.findAll();

    }
 
    public List<Report> getByidDrug()
    {
        
        return rc.findByIdDrug(1);
    }
    public List<Report> getByNameDrug()
    {
        return rc.findByIdDrug(dc.findByNameFirst(DrugName).getIdDrug());
    }
    
    public String byNamePage()
    {
        return "reportBydrug.xhtml";
    }
    /*
    public List<Report> getByDate()
    {
        return rc.findByDate(2005);
    }
    */
    public String byDatePage()
    {
        return "reportByDate.xhtml";
    }
    public String perYear()
    {
        return "reportPerYear.xhtml";
    }
    
    public List<Report> getByReportgt()
    {
        return rc.findByNbreportgt(3000);
    }
    
    public List<Report> getByReportlt()
    {
        return rc.findByNbreportgt(3000);
    }
    
    public List<Report> getByReportbetwn()
    {
        return rc.findByNbreportbetwn(2000, 3000);
    }
    
    public void insert()
    {
        FdaRequest fda = new FdaRequest();
        List<String> names =  Arrays.asList("AVANDIA","ENBREL","HUMIRA","XARELTO","LASIX","OTREXUP","TREXALL","PLAVIX");
        for (String str : names) {

            List<DrugMiddle> list = fda.reportCountry(str);
            String st = "";
            System.out.println(list.size());
            for (DrugMiddle dg : list) {
                st = st + dg.getTerm() + "_";
            }
            rc.insert(str, 2016, fda.nbReports(str), st);
        }
    }

    public String getDrugName() {
        return DrugName;
    }

    public void setDrugName(String DrugName) {
        this.DrugName = DrugName;
    }
    
    
    
}
