/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import entities.Drug;
import Controller.DrugCnx;
import Controller.FdaRequest;
import Controller.FdaRequest.DrugMiddle;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author Cyrille
 */
@ManagedBean
@RequestScoped
public class DrugBean {

    /**
     * Creates a new instance of DrugBean
     */
    DrugCnx drugCnx = new DrugCnx();
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
   
    public DrugBean() {
    }
    
    public String byNamePage(){
        return "drugByName.xhtml";
    }
    
    public List<Drug> getAll()
    {
        return drugCnx.findAll();

    }
 
    public String getByid(int i)
    {
        return drugCnx.findById(i).getName();
    }
    
    public List<Drug> byName()
    {
        return drugCnx.findByName(name);

    }
    public void insertDrug()
    {
        Drug d = new Drug();
        FdaRequest fda = new FdaRequest();
        List<DrugMiddle> list = fda.drugList();
        for (DrugMiddle dm : list){
            d.setName(dm.getTerm());
            drugCnx.insert(d);
        }
        System.out.println("insertDrug done");

    }
 
}
