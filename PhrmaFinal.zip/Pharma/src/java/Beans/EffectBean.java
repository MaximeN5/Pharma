/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Controller.EffectCont;
import entities.Effect;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author Cyrille
 */
@ManagedBean
@RequestScoped
public class EffectBean {

    /**
     * Creates a new instance of EffectBean
     */
    EffectCont effectcnt = new EffectCont();
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String byDrugPage()
    {
        return "effectByName.xhtml";
    }
    public EffectBean() {
    }
     
    public List<Effect> getAll()
    {
        return effectcnt.findAll();

    }
 
    public Effect byid(int i)
    {
        return effectcnt.findById(i);
    }
    
    public List<Effect> getByName()
    {
        return effectcnt.findByName(name);

    }
    public void insertEffects()
    {
        Effect e = new Effect();
        e.setId(1);
        e.setName("aaa");
        System.out.println("avant insert");
        effectcnt.insert("");
        System.out.println("insertEffect done");
    }
    
}
