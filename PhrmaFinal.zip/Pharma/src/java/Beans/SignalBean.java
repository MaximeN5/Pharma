/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Controller.DrugCnx;
import Controller.SignalCont;
import entities.Drug;
import entities.Signal;
import java.util.Arrays;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author Cyrille
 */
@ManagedBean
@RequestScoped
public class SignalBean {

    /**
     * Creates a new instance of SignalBean
     */
    SignalCont sc = new SignalCont();
    DrugCnx dc = new DrugCnx();
    String type;
    String drug;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDrug() {
        return drug;
    }

    public void setDrug(String drug) {
        this.drug = drug;
    }
    
    public SignalBean() {
    }
    
    public void insert(){
        
        List<String> names =  Arrays.asList("AVANDIA","ENBREL","HUMIRA","XARELTO","LASIX","OTREXUP","TREXALL","PLAVIX");
        for (String str : names) 
        {
            //System.out.println(str+"   "+dc.findByNameFirst(str).getIdDrug());
            sc.insert(dc.findByNameFirst(str).getIdDrug());
        }
    }
    
    public List<Signal> byType()
    {
        if(type.compareTo("grave")==0)
            return sc.findBytype(3);
        if(type.compareTo("faible")==0)
            return sc.findBytype(1);
        
        return sc.findBytype(2);
    }
    
    public String byTypePage()
    {
        return "signalByType.xhtml";
    }
    
    public List<Signal> byIddrug()
    {
        return sc.findByIdDrug(dc.findByNameFirst(drug).getIdDrug());
    }
    
    public String byIddrugPage()
    {
        return "signalByDrug.xhtml";
    }
    
}
