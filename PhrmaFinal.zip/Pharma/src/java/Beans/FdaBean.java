/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Controller.DrugCnx;
import Controller.FdaRequest;
import Controller.FdaRequest.DrugMiddle;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author Cyrille
 */
@ManagedBean
@RequestScoped
public class FdaBean {

     Date d1;
     Date d2;
    String drug;

   
    public Date getD1() {
        return d1;
    }

    public void setD1(Date d1) {
        this.d1 = d1;
    }

    public Date getD2() {
        return d2;
    }

    public void setD2(Date d2) {
        this.d2 = d2;
    }

    public String getDrug() {
        return drug;
    }

    public void setDrug(String drug) {
        this.drug = drug;
    }
    
    public FdaBean() {
    }
    
    public void drugList()
    {
        FdaRequest fda = new FdaRequest();
        fda.drugList();
    }
    public String reportBetwn(int drug)
    {
        DrugCnx dc = new DrugCnx();
        System.out.println(drug);
        System.out.println("Rport between"+dc.findById(drug).getName());
        String st = dc.findById(drug).getName();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        FdaRequest fda = new FdaRequest();
        System.out.println("FDA REPORT"+ dateFormat.format(d1)+" , "+ dateFormat.format(d2) +"   "+ drug);
        System.out.println(fda.nbReportsBetwn(st, dateFormat.format(d1), dateFormat.format(d2)));
        return fda.nbReportsBetwn(st, dateFormat.format(d1), dateFormat.format(d2))+"";
    }
    
    public List<DrugMiddle> perYear()
    {
        FdaRequest fda = new FdaRequest();
        return fda.nbReportsPerYear(drug);
    }
    
    
    
}
