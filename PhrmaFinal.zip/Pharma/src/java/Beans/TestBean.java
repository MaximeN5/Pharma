/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Controller.FdaRequest;
import Controller.FdaRequest.DrugMiddle;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.StrictMath.max;
import static java.lang.StrictMath.min;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Cyrille
 */
@ManagedBean
@RequestScoped
public class TestBean {

    /**
     * Creates a new instance of TestBean
     */
    public TestBean() {
    }
    
    public void run(){
            URL url;

        try {
            // get URL content

            String a="http://www.vigiaccess.org";
            url = new URL(a);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // open the stream and put it into BufferedReader
            BufferedReader br;
            if (conn.getResponseCode() >= 400) {
                 br= new BufferedReader(
                        new InputStreamReader(conn.getErrorStream()));
            } else {
                br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream()));
            }
            String inputLine;
            while ((inputLine = br.readLine()) != null) {
                    System.out.println(inputLine);
            }
            br.close();

            System.out.println("Done");

        } catch (Exception e) {
            e.printStackTrace();
        } 
    }
    
    public void testre()
    {
        FdaRequest fda = new FdaRequest();
        System.out.println(fda.nbReportsBetwn("AVANDIA", "20140305", "20150304"));
        
    }
    
}
// xmlns:p="http://primefaces.org/ui"
/*
                <p:calendar  value="#{testBean.date}" ></p:calendar>

*/