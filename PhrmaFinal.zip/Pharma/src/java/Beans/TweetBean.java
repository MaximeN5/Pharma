/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Controller.TweetCont;
import entities.Tweet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author Cyrille
 */
@ManagedBean
@RequestScoped
public class TweetBean {

    /**
     * Creates a new instance of TweetBean
     */
    TweetCont tc = new TweetCont();
    public TweetBean() {
    }
 
    public List<Tweet> getAll()
    {
        return tc.findAll();
    }
 
    public Tweet getByid()
    {
        return tc.findById(1);
    }
    
    public List<Tweet> getByidDrug()
    {
        return tc.findByIdDrug(1);
    }
    
    public List<Tweet> getByDategt() throws ParseException
    {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        return tc.findByDategt(format.parse("2016-01-01T21:06:24.000Z"));
    }
    
    public List<Tweet> getByDatelt() throws ParseException
    {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
       return tc.findByDatelt(format.parse("2016-05-01T21:06:24.000Z"));

    }
    
    public List<Tweet> getByLocal()
    {
        return tc.findByLocal("USA");

    }
    
    public void insert() throws ParseException
    {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        tc.insert("first tweet",1, new Tweet.GsonDate(format.format(new Date())), "USA");
        System.out.println("insertTweet done");

    }
}
