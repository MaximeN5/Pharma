/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import Controller.DrugCnx;
import Controller.FdaRequest;
import Controller.FdaRequest.DrugMiddle;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.inject.Named;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Cyrille
 */
@ManagedBean (name = "mapBean")
@RequestScoped
@Named
public class MapBean {

    String prefix="http://labs.google.com/ridefinder/images/";
    String[] colors = {"mm_20_white.png","mm_20_yellow.png","mm_20_orange.png","mm_20_red.png"}; 
    double[] lat;
    double[] lng ;
    String[] adresse;
    String[] marker;
    String[] metaData;
    
    public MapBean() {
    }

    public String map(int idDrug)
    {
     
        int i = 0;
        long max = 1;
        DrugCnx dc = new DrugCnx();
        FdaRequest fda = new FdaRequest();
        List<DrugMiddle> list = fda.reportCountry(dc.findById(idDrug).getName());
        adresse = new String[list.size()];
        marker = new String[list.size()];
        metaData = new String[list.size()];
        lat = new double[list.size()];
        lng = new double[list.size()];
        if (list==null){
            max = list.get(1).getCount();
            System.out.println("LIST VIDE");
        }
        max = list.get(0).getCount();

        for(DrugMiddle dm :list){
                System.out.println(i);
                System.out.println(list.get(i).getTerm());
            adresse[i]=list.get(i).getTerm();
            metaData[i]=list.get(i).getCount()+"";
            if(list.get(i).getCount()<(max/3))
                marker[i]=prefix+colors[1];
            else if (list.get(i).getCount()>(2*max/3))
                marker[i]=prefix+colors[3];
            else marker[i]=prefix+colors[2];
            i++;
            
               
        }
        return mapMap();
        
    }
    public double[] getLat() {
        return lat;
    }

    public void setLat(double[] lat) {
        this.lat = lat;
    }

    public double[] getLng() {
        return lng;
    }

    public void setLng(double[] lng) {
        this.lng = lng;
    }

    public String[] getAdresse() {
        return adresse;
    }

    public void setAdresse(String[] adresse) {
        this.adresse = adresse;
    }

    public String getPrefix() {
        System.out.println(prefix);
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String[] getMetaData() {
        return metaData;
    }

    public void setMetaData(String[] metaData) {
        this.metaData = metaData;
    }
    
    public String getAdressByi(int i){
        return adresse[i];
    }
    
    public double getLatByi(int i){
        return lat[i];
    }
    
    public double getLngByi(int i){
        return lng[i];
    }
    
    public String getMarkerByi(int i){
        return marker[i];
    }
    
    public String getDataByi(int i){
        return metaData[i];
    }
    @SuppressWarnings("empty-statement")
    public String mapMap() {

        String result = "";
        URL url;
        for (int i = 0; i < adresse.length; i++) {
            
            result = "";
            try {
                url = new URL("https://maps.googleapis.com/maps/api/geocode/json?"
                        + "address=" + adresse[i]
                        + "&key=AIzaSyBheNExBIMOPgKjuHijxXXDiBza-L2jyU8");
                
                System.out.println(url);

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                String output = "";
                BufferedReader br;
                if (conn.getResponseCode() < 400) {
                    br = new BufferedReader(new InputStreamReader(
                            (conn.getInputStream())));

                    while ((output = br.readLine()) != null) {
                        result = result.concat(output);
                    }
                    System.out.println(result);
                    JSONParser parser = new JSONParser();
                    Object resultObject = parser.parse(result);
                    System.out.println(result);

                    JSONObject myJSONResult = (JSONObject) resultObject;
                    JSONArray resu = (JSONArray) myJSONResult.get("results");
                    JSONObject r1 = (JSONObject) resu.get(0);
                    JSONObject re2 = (JSONObject) r1.get("geometry");
                    JSONObject re3 = (JSONObject) re2.get("location");
                    lng[i] = (double) re3.get("lng");
                    lat[i] = (double) re3.get("lat");

                    System.out.println(lat[i] + "   " + lng[i]);
                    System.out.println(re2.get("location"));
                    System.out.println("Premiere boucle " + i);
                    System.out.println(getAdressByi(i) + "    " + getDataByi(i) + "   " + getMarkerByi(i));
                    System.out.println(getLatByi(i) + "   " + getLngByi(i));
                }
            } catch (MalformedURLException ex) {
                Logger.getLogger(MapBean.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(MapBean.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ParseException ex) {
                Logger.getLogger(MapBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return "mapjsf.xhtml";
    }

    @SuppressWarnings("empty-statement")
    public String mapMethode(String[] adress,int[] color, String[] meta) {

        setAdresse(adress);
        lng = new double[adresse.length];
        lat = new double[adresse.length];
        marker = new String[adresse.length];
        setMetaData(meta);
        
        String result = "";
        URL url;
        for (int i = 0; i < adresse.length; i++) {
            
            result = "";
            try {
                url = new URL("https://maps.googleapis.com/maps/api/geocode/json?"
                        + "address=" + adresse[i]
                        + "&key=AIzaSyBheNExBIMOPgKjuHijxXXDiBza-L2jyU8");
                
                System.out.println(url);

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                String output = "";

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));

                while ((output = br.readLine()) != null) {
                    result = result.concat(output);
                }
                System.out.println(result);
                JSONParser parser = new JSONParser();
                Object resultObject = parser.parse(result);
                System.out.println(result);

                JSONObject myJSONResult = (JSONObject) resultObject;
                JSONArray resu = (JSONArray) myJSONResult.get("results");
                JSONObject r1 = (JSONObject) resu.get(0);
                JSONObject re2 = (JSONObject) r1.get("geometry");
                JSONObject re3 = (JSONObject) re2.get("location");
                lng[i] = (double) re3.get("lng");
                lat[i] = (double) re3.get("lat");
                
                marker[i] = prefix+colors[color[i]];

                System.out.println(lat + "   " + lng);
                System.out.println(re2.get("location"));
                System.out.println("Premiere boucle "+i );
                System.out.println(getAdressByi(i)+"    "+getDataByi(i)+"   "+getMarkerByi(i));
                System.out.println(getLatByi(i)+"   "+getLngByi(i));

            } catch (MalformedURLException ex) {
                Logger.getLogger(MapBean.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(MapBean.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ParseException ex) {
                Logger.getLogger(MapBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return "mapjsf";
    }
    public String mapCall(){
        String[] adress = {"paris","casablanca","berlin","rome"};
        int[] color = {0,1,2,3};
        String[] meta = {"Paris","Casablanca","Berlin","Rome"};
        return mapMethode(adress, color, meta);
    }

}

/*
http:// labs.google.com/ridefinder/images/

PREFIX	SUFFIX
mm_20_	*.png	*shadow.png
mm_20_gray		 
mm_20_green		 
mm_20_orange		 
mm_20_purple		 
mm_20_red		 
mm_20_white		 
mm_20_yellow		 
mm_20_black		 
mm_20_blue		 
mm_20_brown		 
mm_20_shadow	 
*/

/*
<h:form>
            <h:link value="#{mapBean.prefix}" ></h:link>
            <h:commandButton action="#{mapBean.mapCall}" value="map"></h:commandButton>
        </h:form>
*/